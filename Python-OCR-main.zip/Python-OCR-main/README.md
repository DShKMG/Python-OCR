# Python-OCR
Python OCR project with TessarOCR
